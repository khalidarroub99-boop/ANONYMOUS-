const settings = {
  packname: '𝑽𝑬𝑿',
  author: '‎',
  botName: "𝑽𝑬𝑿",
  botOwner: '𝑽𝑬𝑿', // Your name
  ownerNumber: '212688926115', //Set your number here without + symbol, just add country code & number without any space
  giphyApiKey: 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
  commandMode: "public",
  maxStoreMessages: 20, 
  storeWriteInterval: 10000,
  description: "بوت لإدارة المجموعات وأتمتة المهام.",
  version: "3.0.7",
  updateZipUrl: "https://github.com/mruniquehacker/Knightbot-MD/archive/refs/heads/main.zip",
};

module.exports = settings;
