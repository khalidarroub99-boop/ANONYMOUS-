// 🧹 Fix for ENOSPC / temp overflow in hosted panels
const fs = require('fs');
const path = require('path');

// Redirect temp storage away from system /tmp
const customTemp = path.join(process.cwd(), 'temp');
if (!fs.existsSync(customTemp)) fs.mkdirSync(customTemp, { recursive: true });
process.env.TMPDIR = customTemp;
process.env.TEMP = customTemp;
process.env.TMP = customTemp;

// Auto-cleaner every 3 hours
setInterval(() => {
    fs.readdir(customTemp, (err, files) => {
        if (err) return;
        for (const file of files) {
            const filePath = path.join(customTemp, file);
            fs.stat(filePath, (err, stats) => {
                if (!err && Date.now() - stats.mtimeMs > 3 * 60 * 60 * 1000) {
                    fs.unlink(filePath, () => { });
                }
            });
        }
    });
    console.log('🧹 تم تنظيف مجلد الملفات المؤقتة تلقائياً');
}, 3 * 60 * 60 * 1000);

const settings = require('./settings');
require('./config.js');
const { isBanned } = require('./lib/isBanned');
const { isSudo } = require('./lib/index');
const isOwnerOrSudo = require('./lib/isOwner');
const isAdmin = require('./lib/isAdmin');
const { checkMuted } = require('./commands/katm');
const { Antilink } = require('./lib/antilink');
const { handleContactDetection } = require('./lib/anticontact');
const { addCommandReaction } = require('./lib/reactions');
const { buildRegistry, findCommand } = require('./lib/commandRegistry');
const { handleProtectionEvent } = require('./commands/protection');


// الأوامر ذاتية التسجيل (name/aliases داخل ملف الأمر)
const commandRegistry = buildRegistry(path.join(__dirname, 'commands'));

// Global settings
global.packname = settings.packname;
global.author = settings.author;
global.channelLink = "https://whatsapp.com/channel/0029Vb8X5mFGpLHOqQ6gTv45";
global.ytch = "𝑽𝑬𝑿";

// Add this near the top of main.js with other global configurations
const channelInfo = {
    contextInfo: {
        forwardingScore: 1,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: '120363412049756642@newsletter',
            newsletterName: '𝑽𝑬𝑿',
            serverMessageId: -1
        }
    }
};

async function handleMessages(sock, messageUpdate, printLog) {
    try {
        const { messages, type } = messageUpdate;
        if (type !== 'notify') return;

        const message = messages[0];
        if (!message?.message) return;

        const chatId = message.key.remoteJid;
        const senderId = message.key.participant || message.key.remoteJid;
        const isGroup = chatId.endsWith('@g.us');
        const senderIsSudo = await isSudo(senderId);
        const senderIsOwnerOrSudo = await isOwnerOrSudo(senderId, sock, chatId);

        // كتم الأعضاء: حذف رسائل المكتوم تلقائياً
        if (isGroup) {
            await checkMuted(sock, message);
        }

        const userMessage = (
            message.message?.conversation?.trim() ||
            message.message?.extendedTextMessage?.text?.trim() ||
            message.message?.imageMessage?.caption?.trim() ||
            message.message?.videoMessage?.caption?.trim() ||
            message.message?.buttonsResponseMessage?.selectedButtonId?.trim() ||
            ''
        ).toLowerCase().replace(/\.\s+/g, '.').trim();

        // Preserve raw message for commands like .tag that need original casing
        const rawText = message.message?.conversation?.trim() ||
            message.message?.extendedTextMessage?.text?.trim() ||
            message.message?.imageMessage?.caption?.trim() ||
            message.message?.videoMessage?.caption?.trim() ||
            '';

        // Only log command usage
        if (userMessage.startsWith('.')) {
            console.log(`📝 تم استخدام أمر في ${isGroup ? 'مجموعة' : 'محادثة خاصة'}: ${userMessage}`);
        }
        // Read bot mode once; don't early-return so moderation can still run in private mode
        let isPublic = true;
        try {
            const data = JSON.parse(fs.readFileSync('./data/messageCount.json'));
            if (typeof data.isPublic === 'boolean') isPublic = data.isPublic;
        } catch (error) {
            console.error('Error checking access mode:', error);
        }
        const isOwnerOrSudoCheck = message.key.fromMe || senderIsOwnerOrSudo;
        // تطابق الأمر من سجل الأوامر (commands/*.js)
        const regMatch = findCommand(commandRegistry, userMessage);
        // Check if user is banned
        if (isBanned(senderId) && !(regMatch && regMatch.runWhileBanned)) {
            if (Math.random() < 0.1) {
                await sock.sendMessage(chatId, {
                    text: '❌ تم حظرك من استخدام البوت. تواصل مع مشرف لإلغاء الحظر.',
                    ...channelInfo
                });
            }
            return;
        }

        if (!message.key.fromMe) {
            // message count tracking removed
        }

        // Check for antilink and anticontact FIRST, before ANY other processing
        if (isGroup) {
            await Antilink(message, sock);
            await handleContactDetection(sock, message);
        }

        // Then check for command prefix
        if (!userMessage.startsWith('.')) {
            return;
        }
        // In private mode, only owner/sudo can run commands
        if (!isPublic && !isOwnerOrSudoCheck) {
            return;
        }

        // توزيع الأوامر ذاتية التسجيل من سجل الأوامر (commands/*.js)
        if (regMatch) {
            const { fn, argText, command } = regMatch;

            const ctx = {
                sock,
                chatId,
                message,
                senderId,
                rawText,
                userMessage,
                isGroup,
                isOwnerOrSudo: isOwnerOrSudoCheck,
                isSenderAdmin: false,
                isBotAdmin: false,
                channelInfo,
                _adminChecked: false,
                async getAdminStatus() {
                    if (!this._adminChecked) {
                        const st = await isAdmin(sock, chatId, senderId);
                        this.isSenderAdmin = st.isSenderAdmin;
                        this.isBotAdmin = st.isBotAdmin;
                        this._adminChecked = true;
                    }
                    return { isSenderAdmin: this.isSenderAdmin, isBotAdmin: this.isBotAdmin };
                },
                async requireGroup(text = '❌ هذا الأمر يُستخدم داخل المجموعات فقط.') {
                    if (this.isGroup) return true;
                    await sock.sendMessage(chatId, { text, ...channelInfo }, { quoted: message });
                    return false;
                },
                async requireBotAdmin(text = 'يرجى ترقية البوت إلى مشرف لاستخدام أوامر المشرفين.') {
                    const { isBotAdmin } = await this.getAdminStatus();
                    if (isBotAdmin) return true;
                    await sock.sendMessage(chatId, { text, ...channelInfo }, { quoted: message });
                    return false;
                },
                async requireSenderAdmin(text = 'عذراً، مشرفو المجموعة فقط يمكنهم استخدام هذا الأمر.') {
                    const { isSenderAdmin } = await this.getAdminStatus();
                    if (isSenderAdmin || this.isOwnerOrSudo) return true;
                    await sock.sendMessage(chatId, { text, ...channelInfo }, { quoted: message });
                    return false;
                },
                async requireOwner(text = '❌ هذا الأمر متاح للمالك أو السودو فقط!') {
                    if (this.isOwnerOrSudo) return true;
                    await sock.sendMessage(chatId, { text, ...channelInfo }, { quoted: message });
                    return false;
                },
                async send(text, extra = {}) {
                    return sock.sendMessage(chatId, { text, ...channelInfo, ...extra }, { quoted: message });
                }
            };

            try {
                await fn(sock, chatId, message, argText, command, ctx);
            } catch (err) {
                console.error('Error in command:', command, err);
            }
            await addCommandReaction(sock, message);
            return;
        }

        if (userMessage.startsWith('.')) {
            await addCommandReaction(sock, message);
        }

    } catch (error) {
        console.error('❌ Error in message handler:', error.message);
        if (chatId) {
            await sock.sendMessage(chatId, {
                text: '❌ فشل في معالجة الأمر!',
                ...channelInfo
            });
        }
    }
}

async function handleGroupParticipantUpdate(sock, update) {
    try {
        const { id, participants, action, author } = update;
        if (!id.endsWith('@g.us')) return;
        await handleProtectionEvent(sock, update);
    } catch (error) {
        console.error('Error in handleGroupParticipantUpdate:', error);
    }
}

module.exports = {
    handleMessages,
    handleGroupParticipantUpdate,
    handleStatus: async (sock, status) => {
        // Status handler removed
    }
};
