const settings = require('../settings');

module.exports = {
    name: 'اوامر',
    aliases: ['help', 'menu', 'الاوامر', 'قائمة'],
    category: 'general',
    description: 'عرض قائمة الأوامر',
    run: async (sock, chatId, message) => {
        const text = '*📌 أوامر البوت:*\n\n' +
            '├─ 🔧 *أدوات*\n' +
            '│  ├─ .فضح — كشف وسائط العرض لمرة واحدة\n' +
            '│  └─ .بنج — فحص سرعة البوت\n\n' +
            '├─ 🛡️ *إدارة المجموعة*\n' +
            '│  ├─ .كتم — كتم عضو أو فك الكتم\n' +
            '│  ├─ .antilink — مكافحة الروابط\n' +
            '│  ├─ .anticontact — مضاد جهات الاتصال\n' +
            '│  └─ .حماية — حماية الإشراف من السرقة\n\n' +
            '├─ 👑 *المالك*\n' +
            '│  ├─ .وضع — تغيير وضع البوت (عام/خاص)\n' +
            '│  ├─ .سودو — إدارة مستخدمي sudo\n' +
            '│  ├─ .سبام — تكرار الرسائل\n' +
            '│  └─ .حويهم — تدمير المجموعة وطرد الجميع\n\n' +
            '├─ 🎮 *أخرى*\n' +
            '│  └─ .تست — إرسال فيديو PTV\n\n' +
            '*⚡ 𝐏𝐨𝐰𝐞𝐫𝐞𝐝 𝐁𝐲 ' + (settings.botName || '𝑽𝑬𝑿') + '*';

        await sock.sendMessage(chatId, { text }, { quoted: message });
    }
};
