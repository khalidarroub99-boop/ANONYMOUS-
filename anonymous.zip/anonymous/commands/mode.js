const { channelInfo } = require('../lib/messageConfig');
const fs = require('fs');

module.exports = {
    name: 'وضع',
    aliases: ['mode'],
    category: 'admin',
    description: 'تغيير وضع البوت (عام/خاص)',
    run: async (sock, chatId, message, argText, command, ctx) => {
        if (!(await ctx.requireOwner())) return;

        let data;
        try {
            data = JSON.parse(fs.readFileSync('./data/messageCount.json'));
        } catch (error) {
            await sock.sendMessage(chatId, {
                text: '❌ *فـشـل فـي قـراءة حـالة وضـع الـبـوت*',
                ...channelInfo
            });
            return;
        }

        const action = (argText || '').trim().toLowerCase();
        if (!action) {
            const currentMode = data.isPublic ? ' عام' : ' خاص';
            await sock.sendMessage(chatId, {
                text: '*وضع البوت الحالي:*' + currentMode + '*\n\nالاستخدام:\n\nوضع public — السماح للجميع\nوضع private — المالك فقط\nوضع عام — السماح للجميع\nوضع خاص — المالك فقط*',
                ...channelInfo
            }, { quoted: message });
            return;
        }

        const isPublic = ['public', 'عام'].includes(action);
        const isPrivate = ['private', 'خاص'].includes(action);

        if (!isPublic && !isPrivate) {
            await sock.sendMessage(chatId, {
                text: '*الاستخدام:\n\nوضع public أو وضع عام\nوضع private أو وضع خاص*',
                ...channelInfo
            }, { quoted: message });
            return;
        }

        try {
            data.isPublic = isPublic;
            fs.writeFileSync('./data/messageCount.json', JSON.stringify(data, null, 2));
            const modeText = isPublic ? 'عام' : 'خاص';
            await sock.sendMessage(chatId, {
                text: '*أصبـح الـبـوت الآن فـي وضـع ' + modeText + ' ✅*',
                ...channelInfo
            }, { quoted: message });
        } catch (error) {
            await sock.sendMessage(chatId, {
                text: '❌ *فـشـل فـي تـحديـث وضـع الـوصـول*',
                ...channelInfo
            });
        }
    }
};
