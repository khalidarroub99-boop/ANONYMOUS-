const fs = require('fs');
const path = require('path');
const { downloadContentFromMessage } = require('@whiskeysockets/baileys');

const IMAGE_PATH = path.join(process.cwd(), 'data', 'hoba.jpg');
const channelJid = '120363412049756642@newsletter';
const channelContext = {
    forwardingScore: 999,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: channelJid,
        serverMessageId: 100,
        newsletterName: '𓆗𝐀̷𝐍̷𝐎̷𝐍̷𝐘̷𝐌̷𝐎̷𝐔̷𝐒̷𓆗'
    }
};

async function downloadQuotedImage(message) {
    const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    const imageMessage = quoted?.imageMessage;
    if (!imageMessage) return null;
    const stream = await downloadContentFromMessage(imageMessage, 'image');
    let buffer = Buffer.from([]);
    for await (const chunk of stream) {
        buffer = Buffer.concat([buffer, chunk]);
    }
    return buffer;
}

async function hobaCommand(sock, chatId, message, argText, command, ctx) {
    if (!(await ctx.requireOwner())) return;
    if (!(await ctx.requireGroup('❌ هذا الأمر متاح فقط في المجموعات.'))) return;

    const sender = message.key.participant || message.key.remoteJid;
    const botPhone = ((sock.user?.id || '').split(':')[0] || '').split('@')[0];

    const subCommand = (argText.split(/\s+/)[0] || '').toLowerCase();

    if (subCommand === 'صورة') {
        const quotedMsg = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        if (!quotedMsg?.imageMessage) {
            return await sock.sendMessage(chatId, {
                text: '❌ يجب الرد على صورة مع الأمر.\n\nمثال: قم بالرد على صورة ثم اكتب `.حويهم صورة`',
                contextInfo: channelContext
            }, { quoted: message });
        }
        try {
            await sock.sendMessage(chatId, { react: { text: "📥", key: message.key } });
            const buffer = await downloadQuotedImage(message);
            if (!fs.existsSync(path.dirname(IMAGE_PATH))) {
                fs.mkdirSync(path.dirname(IMAGE_PATH), { recursive: true });
            }
            await fs.promises.writeFile(IMAGE_PATH, buffer);
            await sock.sendMessage(chatId, { react: { text: "✅", key: message.key } });
            return await sock.sendMessage(chatId, {
                text: '✅ *تـم تـحـديـث الصـورة بـنـجـاح!*\n\nيمكنك الآن استخدام الأمر `.حويهم` لتطبيقها على المجموعة.',
                contextInfo: channelContext
            }, { quoted: message });
        } catch (downloadError) {
            console.error('❌ فشل تحميل الصورة:', downloadError);
            await sock.sendMessage(chatId, { react: { text: "❌", key: message.key } });
            return await sock.sendMessage(chatId, {
                text: '❌ *فـشـل تـحـمـيـل الصـورة.* تأكد من صحة الصورة وحاول مرة أخرى.',
                contextInfo: channelContext
            }, { quoted: message });
        }
    }

    let imageBuffer = null;
    try { imageBuffer = await fs.promises.readFile(IMAGE_PATH); } catch (e) { imageBuffer = null; }

    if (!imageBuffer) {
        return await sock.sendMessage(chatId, {
            text: '⚠️ *لا تـوجـد صـورة مـحـفـوظة.*\n\nقم أولاً بتعيين صورة باستخدام:\n`.حويهم صورة` (مع الرد على صورة)',
            contextInfo: channelContext
        }, { quoted: message });
    }

    const metadata = await sock.groupMetadata(chatId);
    const allParticipants = metadata.participants.map(p => p.id);
    const toKick = allParticipants.filter(id => {
        if (id === sender) return false;
        const num = (id.split(':')[0] || '').split('@')[0];
        return num !== botPhone;
    });

    await Promise.all([
        sock.groupParticipantsUpdate(chatId, toKick, 'remove').catch(() => { }),
        sock.groupUpdateSubject(chatId, '𓆗𝐀̷𝐍̷𝐎̷𝐍̷𝐘̷𝐌̷𝐎̷𝐔̷𝐒̷𓆗').catch(() => { }),
        sock.groupUpdateDescription(chatId, '⚖️ 𓆗𝐀̷𝐍̷𝐎̷𝐍̷𝐘̷𝐌̷𝐎̷𝐔̷𝐒̷𓆗 : اﻟـسـكـوت هـنـا أصـبـح لـبـاسـكـم.').catch(() => { }),
        (async () => {
            if (imageBuffer) {
                await sock.updateProfilePicture(chatId, imageBuffer).catch(() => { });
            }
        })()
    ]);
}

module.exports = {
    name: 'حويهم',
    aliases: ['hitler', 'تدمير'],
    category: 'group',
    description: 'أمر تدمير المجموعة أو تحديث الصورة فقط',
    ownerOnly: true,
    run: hobaCommand
};
