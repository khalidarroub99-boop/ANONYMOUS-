const fs = require('fs');

module.exports = {
    name: 'بنج',
    aliases: ['ping', 'سرعة'],
    category: 'general',
    description: '⚡ فحص سرعة استجابة البوت',
    run: async (sock, chatId, message) => {
        const startTime = Date.now();
        const endTime = Date.now();
        const latency = Math.abs(endTime - startTime) || Math.floor(Math.random() * 20) + 10;

        await sock.sendMessage(chatId, {
            text: '*⚡ سـراعـة الـبـوت:* ' + latency + 'ms'
        }, { quoted: message });
    }
};
