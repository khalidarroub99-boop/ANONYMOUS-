const fs = require('fs');
const path = require('path');
const { downloadContentFromMessage } = require('@whiskeysockets/baileys');

const FRAME_MENU = '⚔️𝐒𝐇𝐀𝐃𝐎𝐖 𝐎𝐅 𝐓𝐇𝐄 𝐅𝐀𝐋𝐋𝐄𝐍⚔️\n\n' +
    ' 🩸 𝐍𝐄𝐕𝐄𝐑 𝐁𝐎𝐖 🩸\n' +
    '            🔥 𝐍𝐄𝐕𝐄𝐑 𝐅𝐄𝐀𝐑 🔥\n' +
    ' ☠️ 𝐍𝐄𝐕𝐄𝐑 𝐒𝐔𝐑𝐑𝐄𝐍𝐃𝐄𝐑 ☠️';

const videoPath = path.join(__dirname, '../assets/note.mp4');

async function testCommand(sock, chatId, message) {
    try {
        const text = (message.message?.conversation || message.message?.extendedTextMessage?.text || '').trim();
        const args = text.split(' ').slice(1);

        if (args[0] === 'اضف') {
            const quotedMsg = message.message.extendedTextMessage?.contextInfo?.quotedMessage;
            const videoMessage = quotedMsg?.videoMessage;

            if (!videoMessage) {
                return await sock.sendMessage(chatId, {
                    text: '*رد عـلـى فيـديـو ثـم أرسـل:* .تست اضف'
                }, { quoted: message });
            }

            await sock.sendMessage(chatId, { text: '*جاری تـحـديـث الـفيديو...*' }, { quoted: message });

            const stream = await downloadContentFromMessage(videoMessage, 'video');
            let buffer = Buffer.alloc(0);
            for await (const chunk of stream) { buffer = Buffer.concat([buffer, chunk]); }

            const assetsDir = path.dirname(videoPath);
            if (!fs.existsSync(assetsDir)) fs.mkdirSync(assetsDir, { recursive: true });
            fs.writeFileSync(videoPath, buffer);

            return await sock.sendMessage(chatId, { text: '✅ *تـم تـحـديـث الـفيديو بـنـجـاح.*' }, { quoted: message });
        }

        if (!fs.existsSync(videoPath)) {
            throw new Error('ملف الفيديو غير موجود. استخدم ".تست اضف" أولاً.');
        }

        await sock.sendMessage(chatId, {
            video: { url: videoPath },
            mimetype: 'video/mp4',
            ptv: true
        }, { quoted: message });

        await sock.sendMessage(chatId, { text: FRAME_MENU }, { quoted: message });

    } catch (error) {
        console.error('[TEST] Error:', error.message || error);
        await sock.sendMessage(chatId, { text: '❌ *حـدث خـطـأ:* ' + error.message }, { quoted: message });
    }
}

module.exports = {
    name: 'تست',
    aliases: ['test'],
    category: 'اختبار',
    description: 'يرسل فيديو PTV أو يحدث الفيديو عند الرد عليه',
    run: testCommand
};
