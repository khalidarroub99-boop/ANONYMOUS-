const { setAntilink, getAntilink, removeAntilink } = require('../lib/index');

async function handleAntilinkCommand(sock, chatId, userMessage, senderId, isSenderAdmin, message, command = '') {
    try {
        if (!isSenderAdmin) {
            await sock.sendMessage(chatId, { text: '❌ *هـذا الأمـر للمـشرفـيـن فـقـط!*' }, { quoted: message });
            return;
        }

        const args = userMessage.slice(command.length + 1).toLowerCase().trim().split(' ');
        const action = args[0];

        if (!action) {
            await sock.sendMessage(chatId, {
                text: '*🔗 إعـداد مـكافـحـة الـروابـط*\n\n*📌 الأوامر:*\n\n.antilink on — التفعيل ✅\n.antilink set delete | kick | warn — اختيار الإجراء ⚙️\n.antilink off — الإيقاف ❌',
                quoted: message
            });
            return;
        }

        switch (action) {
            case 'on': {
                const existingConfig = await getAntilink(chatId, 'on');
                if (existingConfig?.enabled) {
                    await sock.sendMessage(chatId, { text: '✅ *مـكافـحـة الـروابـط مـفـعّلـة بالفعل!*', quoted: message });
                    return;
                }
                const result = await setAntilink(chatId, 'on', 'delete');
                await sock.sendMessage(chatId, { text: result ? '✅ *تـم تـفعـيـل مـكافـحـة الـروابـط بـنـجـاح!*' : '❌ *فـشـل تـفعـيـل مـكافـحـة الـروابـط!*', quoted: message });
                break;
            }
            case 'off': {
                await removeAntilink(chatId, 'on');
                await sock.sendMessage(chatId, { text: '❌ *تـم إيقـاف مـكافـحـة الـروابـط!*', quoted: message });
                break;
            }
            case 'set': {
                if (args.length < 2) {
                    await sock.sendMessage(chatId, { text: '⚠️ *يـرجى تـحديـد الإجـراء:* .antilink set delete | kick | warn', quoted: message });
                    return;
                }
                const setAction = args[1];
                if (!['delete', 'kick', 'warn'].includes(setAction)) {
                    await sock.sendMessage(chatId, { text: '⚠️ *إجـراء غـيـر صـحـيح!* اختر: delete أو kick أو warn', quoted: message });
                    return;
                }
                const setResult = await setAntilink(chatId, 'on', setAction);
                await sock.sendMessage(chatId, { text: setResult ? '✅ *تـم ضـبـط إجـراء مـكافـحـة الـروابـط عـلـى:* ' + setAction : '❌ *فـشـل ضـبـط الإجـراء!*', quoted: message });
                break;
            }
            case 'get': {
                const status = await getAntilink(chatId, 'on');
                const actionConfig = await getAntilink(chatId, 'on');
                await sock.sendMessage(chatId, {
                    text: '*📊 الحـالـة:* ' + (status ? 'ON ✅' : 'OFF ❌') + '\n*⚙️ الإجـراء:* ' + (actionConfig ? actionConfig.action : 'غـيـر مـحـدد ⚠️'),
                    quoted: message
                });
                break;
            }
            default:
                await sock.sendMessage(chatId, { text: '📌 *اسـتخدـم .antilink لـعـرض الاسـتخدام.*' });
        }
    } catch (error) {
        console.error('Error in antilink command:', error);
        await sock.sendMessage(chatId, { text: '🛠️ *خـطـأ أثـنـاء تـنفيـذ أمـر مـكافـحـة الـروابـط!*' });
    }
}

module.exports = {
    name: 'منع-الروابط',
    aliases: ['antilink'],
    category: 'admin',
    description: 'مكافحة الروابط في المجموعات',
    run: async (sock, chatId, message, argText, command, ctx) => {
        if (!(await ctx.requireGroup())) return;
        if (!(await ctx.requireBotAdmin())) return;
        const admin = await ctx.getAdminStatus();
        await handleAntilinkCommand(sock, chatId, ctx.userMessage, ctx.senderId, admin.isSenderAdmin, message, command);
    }
};
