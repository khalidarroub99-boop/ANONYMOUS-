const { downloadContentFromMessage } = require('@whiskeysockets/baileys');

module.exports = {
    name: 'سبام',
    aliases: ['spam'],
    category: 'owner',
    description: 'تكرار الرسائل (للمالك فقط)',
    run: async (sock, chatId, message, argText, command, ctx) => {
        if (!(await ctx.requireOwner())) return;

        const args = argText.trim().split(/\s+/);
        const count = parseInt(args[0]);

        if (isNaN(count) || count <= 0 || count > 50) {
            return await sock.sendMessage(chatId, {
                text: '❌ *عـدد غـيـر صـحـيح (1-50)*\n\nمثال: .سبام 5 نص الرسالة',
                quoted: message
            });
        }

        const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;

        if (quoted) {
            if (quoted.imageMessage) {
                const stream = await downloadContentFromMessage(quoted.imageMessage, 'image');
                let buffer = Buffer.from([]);
                for await (const chunk of stream) { buffer = Buffer.concat([buffer, chunk]); }
                for (let i = 0; i < count; i++) {
                    await sock.sendMessage(chatId, { image: buffer, caption: quoted.imageMessage.caption || '' });
                    await new Promise(res => setTimeout(res, 500));
                }
            } else if (quoted.videoMessage) {
                const stream = await downloadContentFromMessage(quoted.videoMessage, 'video');
                let buffer = Buffer.from([]);
                for await (const chunk of stream) { buffer = Buffer.concat([buffer, chunk]); }
                for (let i = 0; i < count; i++) {
                    await sock.sendMessage(chatId, { video: buffer, caption: quoted.videoMessage.caption || '' });
                    await new Promise(res => setTimeout(res, 500));
                }
            } else {
                const quotedText = quoted.conversation || quoted.extendedTextMessage?.text;
                for (let i = 0; i < count; i++) {
                    await sock.sendMessage(chatId, { text: quotedText });
                    await new Promise(res => setTimeout(res, 500));
                }
            }
        } else {
            const spamText = args.slice(1).join(' ');
            if (!spamText) {
                return await sock.sendMessage(chatId, {
                    text: '❌ *اكتب نـص للسـبام أو رد عـلـى رسـالة*\n\nمثال: .سبام 5 Hello',
                    quoted: message
                });
            }
            for (let i = 0; i < count; i++) {
                await sock.sendMessage(chatId, { text: spamText });
                await new Promise(res => setTimeout(res, 500));
            }
        }
    }
};
