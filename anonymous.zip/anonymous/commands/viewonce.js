const { downloadContentFromMessage } = require('@whiskeysockets/baileys');

async function viewOnceCommand(sock, chatId, message) {
    try {
        const quotedMsg = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;

        if (!quotedMsg) {
            return await sock.sendMessage(chatId, {
                text: '⚠️ *يـرجى الـرد عـلـى صـورة أو فيـديـو مـن نـوع "الـعـرض لـمـرة واحـدة" لـاسـتخـرجـها!*'
            }, { quoted: message });
        }

        const viewOnceMessage =
            quotedMsg.viewOnceMessage?.message ||
            quotedMsg.viewOnceMessageV2?.message ||
            quotedMsg.viewOnceMessageV2Extension?.message ||
            quotedMsg;

        const mediaMessage =
            viewOnceMessage.imageMessage ||
            viewOnceMessage.videoMessage;

        if (!mediaMessage) {
            return await sock.sendMessage(chatId, {
                text: '❌ *الـرسـالـة الـمـردود عـلـيـهـا لـيـسـت وسـائـط مـن نـوع "عـرض لـمـرة واحـدة"!*'
            }, { quoted: message });
        }

        const type = viewOnceMessage.imageMessage ? 'image' : 'video';
        const stream = await downloadContentFromMessage(mediaMessage, type);

        let buffer = Buffer.from([]);
        for await (const chunk of stream) {
            buffer = Buffer.concat([buffer, chunk]);
        }

        if (!buffer || buffer.length === 0) {
            return await sock.sendMessage(chatId, {
                text: '❌ *فـشـل تـحـمـيـل الـوسـائـط، حـاول مـرة أخـرى.*'
            }, { quoted: message });
        }

        const caption = mediaMessage.caption || '✨ 𝑽𝑬𝑿';

        if (type === 'image') {
            await sock.sendMessage(chatId, { image: buffer, caption }, { quoted: message });
        } else {
            await sock.sendMessage(chatId, { video: buffer, caption }, { quoted: message });
        }

    } catch (error) {
        console.error('[viewonce] Error:', error.message || error);
        await sock.sendMessage(chatId, {
            text: '❌ *حـدث خـطـأ أثـنـاء مـحـاولـة كـشـف الـوسـائـط:* ' + (error.message || error)
        }, { quoted: message });
    }
}

module.exports = {
    name: 'فضح',
    aliases: ['كشف', 'عرض'],
    category: 'tools',
    description: 'كشف وسائط العرض لمرة واحدة',
    run: viewOnceCommand
};
