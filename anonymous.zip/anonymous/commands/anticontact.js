const { handleAntiContactCommand } = require('../lib/anticontact');

module.exports = {
    name: 'مضاد-جهات-الاتصال',
    aliases: ['anticontact', 'anticontacts', 'antivcard'],
    category: 'admin',
    description: 'مضاد جهات الاتصال في المجموعات',
    run: async (sock, chatId, message, argText, command, ctx) => {
        if (!(await ctx.requireGroup())) return;
        if (!(await ctx.requireBotAdmin())) return;
        if (!(await ctx.requireSenderAdmin())) return;
        await handleAntiContactCommand(sock, chatId, message, argText.trim(), ctx);
    }
};
