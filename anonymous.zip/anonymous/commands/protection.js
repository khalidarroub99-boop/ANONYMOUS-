const fs = require('fs');
const path = require('path');

const CONFIG_PATH = path.join(process.cwd(), 'data', 'protection.json');
let protectionEnabled = false;

const cleanNumber = (id) => id ? id.toString().split(':')[0].split('@')[0].replace(/\D/g, '') : '';

const loadConfig = () => {
    try {
        if (!fs.existsSync(CONFIG_PATH)) return { vipNumbers: [] };
        return JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf-8'));
    } catch (e) { return { vipNumbers: [] }; }
};

const saveConfig = (config) => {
    try {
        const dir = path.dirname(CONFIG_PATH);
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
        fs.writeFileSync(CONFIG_PATH, JSON.stringify(config, null, 2));
    } catch (e) {}
};

const getEliteNumbers = () => loadConfig().vipNumbers.map(num => cleanNumber(num));

async function handleProtectionEvent(sock, update) {
    if (!protectionEnabled) return;
    if (update.action !== 'promote' && update.action !== 'demote') return;

    const eliteNumbers = getEliteNumbers();
    const actorNumber = cleanNumber(update.author);
    const botNumber = cleanNumber(sock.user.id);

    if (actorNumber === botNumber || eliteNumbers.includes(actorNumber)) return;

    const groupJid = update.id;
    await sock.groupParticipantsUpdate(groupJid, [update.author], 'demote').catch(() => {});

    const metadata = await sock.groupMetadata(groupJid);
    const eliteParticipants = metadata.participants.filter(p => eliteNumbers.includes(cleanNumber(p.id)));

    for (const p of eliteParticipants) {
        if (!p.admin) {
            await sock.groupParticipantsUpdate(groupJid, [p.id], 'promote').catch(() => {});
        }
    }

    const text = '*تـم كـشـف خاﻳﻦ 😐\n\nالـخاﻳﻦ:* @' + actorNumber + '\n*المـجـمـوعـة:* ' + metadata.subject;
    await sock.sendMessage(groupJid, { text, mentions: [update.author] });
}

module.exports = {
    name: 'حماية',
    aliases: ['protect', 'amn'],
    category: 'admin',
    description: 'تفعيل/إيقاف حماية الإشراف',
    run: async (sock, chatId, message, argText, command, ctx) => {
        if (!(await ctx.requireGroup())) return;
        if (!(await ctx.requireOwner())) return;

        const args = argText.trim().split(/\s+/);
        const sub = args[0] || '';

        if (sub === 'اضافة' || sub === 'add') {
            const number = args[1]?.replace(/[^0-9]/g, '');
            if (!number) {
                return await sock.sendMessage(chatId, { text: '⚠️ *أضـف رقـم بـعـد الأمـر*\n\nمثال: .حماية اضافة 212600000000', quoted: message });
            }
            const config = loadConfig();
            if (!config.vipNumbers.includes(number)) {
                config.vipNumbers.push(number);
                saveConfig(config);
            }
            return await sock.sendMessage(chatId, { text: '✅ *تـم إضـافـة الـرقـم ' + number + ' إلـى قـائمـة الـنخبـة*', quoted: message });
        }

        if (sub === 'حذف' || sub === 'remove') {
            const number = args[1]?.replace(/[^0-9]/g, '');
            if (!number) {
                return await sock.sendMessage(chatId, { text: '⚠️ *اكتب الـرقـم بـعـد الأمـر*\n\nمثال: .حماية حذف 212600000000', quoted: message });
            }
            const config = loadConfig();
            config.vipNumbers = config.vipNumbers.filter(n => n !== number);
            saveConfig(config);
            return await sock.sendMessage(chatId, { text: '✅ *تـم حـذف الـرقـم ' + number + ' مـن قـائمـة الـنخبـة*', quoted: message });
        }

        if (sub === 'قائمة' || sub === 'list') {
            const numbers = getEliteNumbers();
            if (numbers.length === 0) {
                return await sock.sendMessage(chatId, { text: '📋 *قـائمـة الـنخبـة فـارغـة*', quoted: message });
            }
            const list = numbers.map((n, i) => (i + 1) + '. ' + n).join('\n');
            return await sock.sendMessage(chatId, { text: '*قـائمـة الـنخبـة:*\n\n' + list, quoted: message });
        }

        protectionEnabled = !protectionEnabled;
        await sock.sendMessage(chatId, {
            text: protectionEnabled
                ? '✅ *تـم تـفعـيـل الـحمايـة بـنـجـاح!*\n\nالآن أي شخص يسحب أو يرقّي إشراف بدون إذن سيتم سحب إشرافه فوراً.'
                : '❌ *تـم إيقـاف الـحمايـة.*',
            quoted: message
        });
    },
    handleProtectionEvent
};
