const { channelInfo } = require('../lib/messageConfig');

let mutedUsers = {};

const checkMuted = async (sock, msg) => {
    try {
        const from = msg.key.remoteJid;
        if (!from.endsWith('@g.us')) return;
        if (msg.key.fromMe) return;

        const sender = msg.key.participant || msg.key.remoteJid;
        const senderNumber = sender.split('@')[0];

        if (mutedUsers[from] && mutedUsers[from][senderNumber]) {
            const muteData = mutedUsers[from][senderNumber];

            if (muteData.until && muteData.until < Date.now()) {
                delete mutedUsers[from][senderNumber];
                return;
            }

            await sock.sendMessage(from, { delete: msg.key });

            if (!muteData.lastWarning || Date.now() - muteData.lastWarning > 30000) {
                mutedUsers[from][senderNumber].lastWarning = Date.now();

                let durationText = '';
                if (muteData.until) {
                    const remaining = Math.ceil((muteData.until - Date.now()) / 60000);
                    durationText = '\n⏰ المتبقي: ' + remaining + ' دقيقة';
                }

                await sock.sendMessage(from, {
                    text: '🔇 *مـكتـوم* 🔇\n@' + senderNumber + ' لا يمكنك التكلم' + durationText,
                    mentions: [sender]
                });
            }
        }
    } catch (e) {}
};

const muteUser = async (from, userId, duration, reason, adminName) => {
    const userNumber = userId.split('@')[0];
    if (!mutedUsers[from]) mutedUsers[from] = {};
    let until = null;
    let durationText = 'دائم';
    if (duration && duration > 0) {
        until = Date.now() + (duration * 60 * 1000);
        durationText = duration + ' دقيقة';
    }
    mutedUsers[from][userNumber] = { mutedAt: Date.now(), until, reason: reason || 'بدون سبب', mutedBy: adminName || 'أدمن' };
    return { userNumber, durationText };
};

const unmuteUser = (from, userId) => {
    const userNumber = userId.split('@')[0];
    if (mutedUsers[from] && mutedUsers[from][userNumber]) {
        delete mutedUsers[from][userNumber];
        return true;
    }
    return false;
};

const getMutedList = (from) => {
    if (!mutedUsers[from]) return [];
    const list = [];
    const now = Date.now();
    for (const [userId, data] of Object.entries(mutedUsers[from])) {
        const isExpired = data.until && data.until < now;
        if (!isExpired) {
            let remaining = 'دائم';
            if (data.until) { remaining = Math.ceil((data.until - now) / 60000) + ' دقيقة'; }
            list.push({ userId, remaining, reason: data.reason, mutedBy: data.mutedBy });
        } else if (isExpired) {
            delete mutedUsers[from][userId];
        }
    }
    return list;
};

async function katmCommand(sock, chatId, message) {
    const from = chatId;
    const sender = message.key?.participant || message.key?.remoteJid;

    if (!from.endsWith('@g.us')) {
        return await sock.sendMessage(from, { text: '❌ *هـذا الأمـر يـُستخدم داخـل المـجـموعـات فـقـط.*', ...channelInfo }, { quoted: message });
    }

    const text = (message.message?.conversation || message.message?.extendedTextMessage?.text || '').trim();
    const args = text.split(/\s+/).slice(1);

    const reply = (txt, opts = {}) => sock.sendMessage(from, { text: txt, ...opts, ...channelInfo }, { quoted: message });

    if (args[0] === 'قائمة' || args[0] === 'list') {
        const mutedList = getMutedList(from);
        if (mutedList.length === 0) {
            return reply('📋 *لا يـوجـد أعضـاء مـكتومـيـن فـي المـجـموعـة*');
        }
        let listText = '🔇 *قـائمـة الـمـكتومـيـن* 🔇\n\n';
        const mentions = [];
        for (let i = 0; i < mutedList.length; i++) {
            const m = mutedList[i];
            mentions.push(m.userId + '@s.whatsapp.net');
            listText += (i + 1) + '️⃣ ' + m.userId + '\n   📝 ' + m.reason + '\n   ⏰ متبقي: ' + m.remaining + '\n   👮 بواسطة: ' + m.mutedBy + '\n\n';
        }
        listText += '📊 *الإجمالي:* ' + mutedList.length + ' عضو';
        return await sock.sendMessage(from, { text: listText, mentions, ...channelInfo }, { quoted: message });
    }

    if (args[0] === 'فك' || args[0] === 'unmute') {
        if (args.length < 2) { return reply('⚠️ *طريقة الاستخدام:*\n.كتم فك @مستخدم'); }
        const mentionedJid = message.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
        let targetUser = mentionedJid;
        if (!targetUser && args[1]) {
            const numberMatch = args[1].match(/(\d{10,15})/);
            if (numberMatch) { targetUser = numberMatch[1] + '@s.whatsapp.net'; }
        }
        if (!targetUser) { return reply('⚠️ *قـم بـمـنشن العضـو*\nمثـال: .كتم فك @مستخدم'); }
        const targetNumber = targetUser.split('@')[0];
        if (unmuteUser(from, targetUser)) {
            return reply('✅ *تـم فـك الـكـتـم عـن* @' + targetNumber, { mentions: [targetUser] });
        } else {
            return reply('❌ *العضـو* @' + targetNumber + ' *لـيـس مـكتـومـاً*', { mentions: [targetUser] });
        }
    }

    let targetUser = message.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
    if (!targetUser) {
        const quotedMsg = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        if (quotedMsg && quotedMsg.key && quotedMsg.key.participant) { targetUser = quotedMsg.key.participant; }
    }
    if (!targetUser && args[0]) {
        const numberMatch = args[0].match(/(\d{10,15})/);
        if (numberMatch) { targetUser = numberMatch[1] + '@s.whatsapp.net'; }
    }

    if (!targetUser) {
        return reply(
            '⚠️ *طريقة الاستخدام:*\n\n' +
            '📌 *كتم عضو:* .كتم @مستخدم [المدة] [السبب]\n' +
            '📌 *فك الكتم:* .كتم فك @مستخدم\n' +
            '📌 *قائمة المكتمين:* .كتم قائمة'
        );
    }

    if (targetUser === sock.user.id || (sock.user.lid && targetUser === sock.user.lid)) {
        return reply('❌ *لا يـمكـنـك كـتـم الـبـوت نـفـسه*');
    }

    let duration = null;
    let reason = '';
    let remainingArgs = [...args];
    if (remainingArgs.length > 0 && remainingArgs[0].startsWith('@')) { remainingArgs.shift(); }
    if (remainingArgs.length > 0 && !isNaN(parseInt(remainingArgs[0]))) { duration = parseInt(remainingArgs[0]); remainingArgs.shift(); }
    if (remainingArgs.length > 0) { reason = remainingArgs.join(' '); } else { reason = 'بدون سبب'; }

    let durationText = 'دائم';
    if (duration) {
        if (duration >= 1440) { durationText = Math.floor(duration / 1440) + ' يوم'; }
        else if (duration >= 60) { durationText = Math.floor(duration / 60) + ' ساعة'; }
        else { durationText = duration + ' دقيقة'; }
    }

    const adminNumber = sender?.split('@')[0] || 'أدمن';
    const targetNumber = targetUser.split('@')[0];

    await muteUser(from, targetUser, duration, reason, adminNumber);

    await sock.sendMessage(from, {
        text: '🔇 *تـم كـتـم الـعضـو* 🔇\n\n👤 العضو: @' + targetNumber + '\n⏰ المدة: ' + durationText + '\n📝 السبب: ' + reason + '\n👮 تم بواسطة: @' + adminNumber + '\n\n⚠️ سـيـتـم حـذف أي رسـالـة يـرسـلهـا تـلقـائـيـاً',
        mentions: [targetUser, sender],
        ...channelInfo
    }, { quoted: message });
}

module.exports = {
    name: 'كتم',
    aliases: ['katm'],
    category: 'إدارة',
    description: 'كتم عضو أو فك الكتم أو عرض المكتمين',
    run: async (sock, chatId, message, argText, command, ctx) => {
        if (!(await ctx.requireGroup())) return;
        if (!(await ctx.requireBotAdmin())) return;
        if (!(await ctx.requireSenderAdmin())) return;
        await katmCommand(sock, chatId, message);
    },
    checkMuted
};
